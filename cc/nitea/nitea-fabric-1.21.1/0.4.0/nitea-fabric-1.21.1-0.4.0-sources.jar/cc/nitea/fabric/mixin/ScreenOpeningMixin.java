package cc.nitea.fabric.mixin;

import cc.nitea.client.NiteaScreens;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** Lets Nitea replace the title screen with its consent screen the first time it opens (NeoForge's ScreenEvent.Opening). */
@Mixin(class_310.class)
abstract class ScreenOpeningMixin {
    // setScreen(screen) with a screen to open
    @ModifyVariable(method = "setScreen", at = @At("HEAD"), argsOnly = true)
    private class_437 nitea$opening(class_437 screen) {
        return NiteaScreens.opening(screen);
    }

    // setScreen(null) outside a world picks the title screen itself
    @ModifyVariable(method = "setScreen", at = @At("STORE"), argsOnly = true)
    private class_437 nitea$openingDefault(class_437 screen) {
        return NiteaScreens.opening(screen);
    }
}
