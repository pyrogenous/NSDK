package cc.nitea.fabric.mixin;

import cc.nitea.client.NiteaScreens;
import net.minecraft.class_2561;
import net.minecraft.class_437;
import net.minecraft.class_442;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Adds Nitea's button once the title screen created its widgets (NeoForge's ScreenEvent.Init.Post). */
@Mixin(class_442.class)
abstract class TitleScreenMixin extends class_437 {
    private TitleScreenMixin(class_2561 title) {
        super(title);
    }

    @Inject(method = "init", at = @At("RETURN"))
    private void nitea$initialized(CallbackInfo info) {
        NiteaScreens.initialized(this, method_25396(), widget -> method_37063(widget));
    }
}
