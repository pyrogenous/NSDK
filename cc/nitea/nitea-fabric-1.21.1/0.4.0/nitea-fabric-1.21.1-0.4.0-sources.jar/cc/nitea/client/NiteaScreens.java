package cc.nitea.client;

import cc.nitea.NiteaConsent;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_1011;
import net.minecraft.class_1043;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_442;
import net.minecraft.class_7919;

/**
 * Nitea's in-game screens for this Minecraft version, shared by every loader: asks the player once, on the title
 * screen, whether mods may send reports, and adds a Nitea button next to the title screen's small icon buttons to
 * change that choice later. Each loader forwards two moments here: a screen about to open, and the title screen
 * creating its widgets (NeoForge and Forge through their screen events, Fabric through mixins).
 *
 * <p>Nitea is a library, not a mod, so it has no resource pack: its texts are in {@link NiteaText} and its icon is
 * read from the jar and uploaded as a texture of its own.
 */
public final class NiteaScreens {
    private static final class_2960 ICON = class_2960.method_60655("nitea", "dynamic/icon");
    private static final int ICON_SIZE = 20;
    private static final int ICON_SPACING = 4;

    // Nothing happens until a mod calls Nitea.init: Fabric's mixins run whether or not a mod uses Nitea
    private static volatile boolean installed;
    private static Function<String, String> displayNames = modId -> null;
    // Asked at most once per launch, even if the player leaves the screen some other way
    private static boolean askedThisLaunch;
    private static boolean iconLoaded;

    private NiteaScreens() {}

    /** Turns the screens on. {@code displayNames} gives a mod's name from the loader, or null. */
    public static void install(Function<String, String> displayNames) {
        NiteaScreens.displayNames = displayNames;
        installed = true;
        NiteaConsent.markPromptAvailable();
    }

    /**
     * A screen is about to open: the first time it's the title screen, ask instead. The answer is saved, so a
     * choice is never asked again. Returns the screen to open.
     */
    public static class_437 opening(class_437 screen) {
        if (!installed || askedThisLaunch || !(screen instanceof class_442)) return screen;
        if (!NiteaConsent.shouldAsk() || NiteaConsent.mods().isEmpty()) return screen;
        askedThisLaunch = true;
        return new NiteaConsentScreen(screen, true);
    }

    /** A screen created its widgets: on the title screen, adds the Nitea button with {@code add}. */
    public static void initialized(class_437 screen, List<? extends class_364> widgets, Consumer<class_339> add) {
        if (!installed || !(screen instanceof class_442)) return;
        class_4185 button = new IconButton(pressed -> class_310.method_1551().method_1507(new NiteaConsentScreen(screen, false)));
        button.method_47400(class_7919.method_47407(NiteaText.BUTTON_TOOLTIP));
        placeInIconRow(button, widgets);
        add.accept(button);
    }

    static String displayName(String modId) {
        String name = displayNames.apply(modId);
        return name != null ? name : modId;
    }

    // When the title screen centres a row of square buttons (mods, friends, language, accessibility), join it and
    // keep it centred. When another mod rearranged the screen and there's no such row, fall back to the top-left corner.
    private static void placeInIconRow(class_4185 button, List<? extends class_364> listeners) {
        Map<Integer, List<class_339>> rows = new HashMap<>();
        for (class_364 listener : listeners) {
            if (listener instanceof class_339 widget && widget.method_25368() == ICON_SIZE && widget.method_25364() == ICON_SIZE) {
                rows.computeIfAbsent(widget.method_46427(), y -> new ArrayList<>()).add(widget);
            }
        }
        List<class_339> row = rows.values().stream().max(Comparator.comparingInt(List::size)).orElse(List.of());
        if (row.isEmpty()) {
            button.method_48229(4, 4);
            return;
        }
        row.sort(Comparator.comparingInt(class_339::method_46426));
        class_339 first = row.get(0);
        boolean adjacent = row.size() >= 2;
        for (int i = 1; i < row.size(); i++) {
            if (row.get(i).method_46426() - (row.get(i - 1).method_46426() + ICON_SIZE) > ICON_SPACING * 2) adjacent = false;
        }
        // Square buttons at the ends of the main buttons (language on the left, accessibility on the right):
        // go left of the leftmost one instead of rearranging them
        if (!adjacent) {
            if (first.method_46426() < ICON_SIZE + ICON_SPACING) button.method_48229(4, 4);
            else button.method_48229(first.method_46426() - ICON_SIZE - ICON_SPACING, first.method_46427());
            return;
        }
        int shift = (ICON_SIZE + ICON_SPACING) / 2;
        int right = Integer.MIN_VALUE;
        for (class_339 widget : row) {
            widget.method_46421(widget.method_46426() - shift);
            right = Math.max(right, widget.method_46426() + widget.method_25368());
        }
        button.method_48229(right + ICON_SPACING, row.get(0).method_46427());
    }

    // Uploads icon.png from this jar the first time the button is drawn
    private static boolean loadIcon() {
        if (iconLoaded) return true;
        try (InputStream in = NiteaScreens.class.getResourceAsStream("icon.png")) {
            if (in == null) return false;
            class_310.method_1551().method_1531().method_4616(ICON, new class_1043(class_1011.method_4309(in)));
            iconLoaded = true;
        } catch (IOException ignored) {
            // No icon: the button still works, it's just blank
        }
        return iconLoaded;
    }

    /** A square button like the title screen's language and accessibility buttons, with Nitea's icon. */
    private static final class IconButton extends class_4185 {
        IconButton(class_4241 onPress) {
            super(0, 0, ICON_SIZE, ICON_SIZE, NiteaText.BUTTON, onPress, field_40754);
        }

        @Override
        protected void method_48579(class_332 graphics, int mouseX, int mouseY, float partialTick) {
            // The square button background without its label, then the icon on top
            class_2561 label = method_25369();
            method_25355(class_2561.method_43473());
            super.method_48579(graphics, mouseX, mouseY, partialTick);
            method_25355(label);
            if (loadIcon()) graphics.method_25290(ICON, method_46426() + 2, method_46427() + 2, 0, 0, 16, 16, 16, 16);
        }
    }
}
