package cc.nitea.client;

import cc.nitea.internal.ConsentText;
import net.minecraft.class_2561;

/** Nitea's texts (from {@link ConsentText}, shared by every loader and version) as game components. */
final class NiteaText {
    static final class_2561 BUTTON = class_2561.method_43470(ConsentText.BUTTON);
    static final class_2561 BUTTON_TOOLTIP = class_2561.method_43470(ConsentText.BUTTON_TOOLTIP);
    static final class_2561 CONSENT_TITLE = class_2561.method_43470(ConsentText.CONSENT_TITLE);
    static final class_2561 PREFERENCES_TITLE = class_2561.method_43470(ConsentText.PREFERENCES_TITLE);
    static final class_2561 INTRO = class_2561.method_43470(ConsentText.INTRO);
    static final class_2561 DETAILS = class_2561.method_43470(ConsentText.DETAILS);
    static final class_2561 CHANGE = class_2561.method_43470(ConsentText.CHANGE);
    static final String STATUS = ConsentText.STATUS;
    static final class_2561 STATUS_GRANTED = class_2561.method_43470(ConsentText.STATUS_GRANTED);
    static final class_2561 STATUS_DENIED = class_2561.method_43470(ConsentText.STATUS_DENIED);
    static final class_2561 STATUS_UNDECIDED = class_2561.method_43470(ConsentText.STATUS_UNDECIDED);
    static final class_2561 ALLOW = class_2561.method_43470(ConsentText.ALLOW);
    static final class_2561 DENY = class_2561.method_43470(ConsentText.DENY);
    static final class_2561 STOP = class_2561.method_43470(ConsentText.STOP);
    static final class_2561 PRIVACY = class_2561.method_43470(ConsentText.PRIVACY);

    private NiteaText() {}
}
