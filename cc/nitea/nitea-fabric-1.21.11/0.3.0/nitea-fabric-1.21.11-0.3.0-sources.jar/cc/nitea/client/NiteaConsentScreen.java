package cc.nitea.client;

import cc.nitea.NiteaConsent;
import cc.nitea.internal.ConsentText;
import net.minecraft.class_2561;
import net.minecraft.class_407;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_5250;
import net.minecraft.class_7940;
import net.minecraft.class_8132;
import net.minecraft.class_8667;

/**
 * Nitea's consent screen. Shown once, the first time the title screen opens ({@code firstTime}: the player must pick
 * an answer), then from the Nitea button on the title screen as the preferences screen, where they can opt in or
 * out again. The choice belongs to Nitea and covers every mod using it.
 */
public final class NiteaConsentScreen extends class_437 {
    private static final String PRIVACY_POLICY = ConsentText.PRIVACY_POLICY_URL;
    private static final int TEXT_WIDTH = 320;
    private static final int GRAY = 0xFFA0A0A0;

    private final class_437 parent;
    private final boolean firstTime;
    private class_8132 layout;

    public NiteaConsentScreen(class_437 parent, boolean firstTime) {
        super(firstTime ? NiteaText.CONSENT_TITLE : NiteaText.PREFERENCES_TITLE);
        this.parent = parent;
        this.firstTime = firstTime;
    }

    @Override
    protected void method_25426() {
        layout = new class_8132(this, 33, 60);
        layout.method_57726(field_22785, field_22793);

        class_8667 content = layout.method_48999(class_8667.method_52741().method_52735(8));
        content.method_52740().method_46467();
        if (!firstTime) content.method_52736(text(class_2561.method_43470(NiteaText.STATUS).method_10852(status())));
        content.method_52736(text(NiteaText.INTRO));
        content.method_52736(text(modNames()));
        content.method_52736(text(NiteaText.DETAILS.method_27661().method_54663(GRAY)));
        content.method_52736(text(NiteaText.CHANGE.method_27661().method_54663(GRAY)));

        class_8667 footer = layout.method_48996(class_8667.method_52741().method_52735(4));
        footer.method_52740().method_46467();
        class_8667 choice = footer.method_52736(class_8667.method_52742().method_52735(8));
        NiteaConsent.State state = NiteaConsent.state();
        class_4185 allow = choice.method_52736(class_4185.method_46430(NiteaText.ALLOW, b -> choose(true)).method_46431());
        class_4185 deny = choice.method_52736(class_4185.method_46430(
                firstTime ? NiteaText.DENY : NiteaText.STOP, b -> choose(false)).method_46431());
        if (!firstTime) {
            allow.field_22763 = state != NiteaConsent.State.GRANTED;
            deny.field_22763 = state != NiteaConsent.State.DENIED;
        }
        class_8667 other = footer.method_52736(class_8667.method_52742().method_52735(8));
        other.method_52736(class_4185.method_46430(NiteaText.PRIVACY, class_407.method_49625(this, PRIVACY_POLICY)).method_46431());
        if (!firstTime) other.method_52736(class_4185.method_46430(class_5244.field_24334, b -> method_25419()).method_46431());

        layout.method_48206(this::method_37063);
        method_48640();
    }

    @Override
    protected void method_48640() {
        layout.method_48222();
    }

    private class_7940 text(class_2561 component) {
        return new class_7940(component, field_22793).method_48984(Math.min(TEXT_WIDTH, field_22789 - 40)).method_48981(true);
    }

    private void choose(boolean allow) {
        if (allow) NiteaConsent.grant();
        else NiteaConsent.deny();
        if (firstTime) method_25419();
        else method_41843();
    }

    private static class_2561 status() {
        return switch (NiteaConsent.state()) {
            case GRANTED -> NiteaText.STATUS_GRANTED.method_27661().method_54663(0xFF55FF55);
            case DENIED -> NiteaText.STATUS_DENIED.method_27661().method_54663(0xFFFF5555);
            case UNDECIDED -> NiteaText.STATUS_UNDECIDED.method_27661().method_54663(0xFFFFFF55);
        };
    }

    // "Example Mod, Other Mod", by display name
    private static class_2561 modNames() {
        class_5250 names = class_2561.method_43473();
        boolean first = true;
        for (String modId : NiteaConsent.mods()) {
            if (!first) names.method_27693(", ");
            first = false;
            names.method_27693(NiteaScreens.displayName(modId));
        }
        return names.method_54663(0xFFFFFFFF);
    }

    // The first time, the player has to pick an answer
    @Override
    public boolean method_25422() {
        return !firstTime;
    }

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }
}
